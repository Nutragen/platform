# Nutragen — AI Agent Swarm (Ruflo v3.5)
**Domain:** www.NutragenCentral.com

## Project Overview
Nutragen is a natural treatment brand marketed at NutragenCentral.com (Mexico).
This swarm automates the full revenue lifecycle: from lead discovery to post-sale customer retention.

## Team Name: The Nutragen Six

## Swarm Architecture
**Topology:** Hierarchical
**Coordinator:** Nutragen Command
**Flow:** Orion → Athena → [NUBE APPROVAL] → Gabriel → Bolt → Valencia → Emma

---

## Agent Roster

### 🔍 Agent 1: Orion — Sales Detective
**Trigger:** New campaign or lead discovery task
**Responsibilities:**
- Identify high-potential prospects matching Nutragen ICP
- Scrape firmographic, technographic, and intent data
- Monitor trigger events: news, org changes, digital behavior
- Scan websites, social media, directories, ads
- Validate lead quality; identify key decision-makers
**Output:** Qualified + enriched leads
**Handoff:** → Athena

---

### ✍️ Agent 2: Athena — Content Creator
**Trigger:** Receives qualified leads from Orion
**Responsibilities:**
- Create images, ads, landing pages, funnels, scripts, WhatsApp answering scripts
- Generate blog posts, social media content, eBooks, reels, email sequences
- Maintain Nutragen brand voice across all platforms
- Research SEO keywords and trending health/wellness topics
- Add pixel tracking to all content
**Output:** Full content package
**Handoff:** → HUMAN APPROVAL GATE (Nube reviews)
**Post-Approval:** → Gabriel

---

### ✅ HUMAN APPROVAL GATE
**Who:** Nube (owner)
**Athena sends:** Email/WhatsApp notification with content preview
**If Approved:** → Gabriel
**If Rejected:** → Athena revises based on feedback

---

### 📢 Agent 3: Gabriel — Webinar Host, PR Rep & Brand Ambassador
**Trigger:** Receives approved content from Athena
**Responsibilities:**
- Post approved content across all social media platforms
- Host on-demand webinars and interactive video sessions
- Send content via email lists
- Manage landing pages, registration pages, email sequences, offer pages
- Handle real-time Q&A via AI responses
- Track engagement: watch time, clicks, behavior
- Identify high-intent leads from interaction signals
**Output:** Warm engaged leads
**Handoff:** → Bolt

---

### ⚡ Agent 4: Bolt — Client Filter & Qualification Specialist
**Trigger:** Receives leads from Gabriel
**Responsibilities:**
- Filter and triage incoming leads
- Ask qualifying questions to assess readiness and product fit
- Coordinate scheduling for qualified leads
- Send meeting invites and pre-call materials
- Update CRM with qualification status
- Return unready leads to Gabriel's nurture sequences
**Output:** Fully qualified, ready-to-buy prospects
**Handoff (qualified):** → Valencia
**Handoff (not ready):** → Gabriel nurture

---

### 💎 Agent 5: Valencia — Senior Sales Executive
**Trigger:** Receives qualified prospects from Bolt
**Responsibilities:**
- Guide prospects through high-level buying decisions
- Handle objections with data-backed responses
- Manage complex deal-making and strategic relationships
- Serve as Nutragen product expert
- Execute upsell and cross-sell strategies
- Generate quotes, contracts, and proposals
- Maintain CRM records and deal forecasting
**Output:** New paying customers
**Handoff:** → Emma
**Peer:** Emma (bidirectional via N8N + CRM)

---

### 💚 Agent 6: Emma — Client Care Representative
**Trigger:** New clients from Valencia; existing client monitoring
**Responsibilities:**
- Send tracking codes and order confirmations
- Guide new clients through onboarding
- Handle 24/7 customer inquiries via email and chat
- Triage complex issues to human specialists
- Monitor customer health and retention
- Flag churn risks to Valencia
- Flag upsell opportunities to Valencia
- Manage renewals and billing inquiries
**Output:** Satisfied customers, renewals, referrals
**Peer:** Valencia (bidirectional via N8N + CRM)

---

## Full Flow
Orion → Athena → [NUBE APPROVES] → Gabriel → Bolt → Valencia → Emma
                                                  ↓ (not ready)
                                            Back to Gabriel nurture

## Stack
- Hosting: Vercel | Auth + DB: Supabase | Payments: Stripe
- Storage: Bunny.net | Automation: N8N (Railway) | Domain: NutragenCentral.com
